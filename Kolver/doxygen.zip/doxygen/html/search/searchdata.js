var indexSectionsWithContent =
{
  0: "cdeghiklmrs",
  1: "km",
  2: "k",
  3: "cdeghiklmrs",
  4: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Properties"
};

