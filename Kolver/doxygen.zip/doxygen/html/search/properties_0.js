var searchData=
[
  ['csvcolumnheadersingleline_0',['csvColumnHeaderSingleLine',['../class_kolver_1_1_kducer_tightening_result.html#acff43b8d8c95b7cf976eb29d00d7f62a',1,'Kolver::KducerTighteningResult']]]
];
