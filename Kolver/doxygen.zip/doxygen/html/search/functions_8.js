var searchData=
[
  ['modbusexception_0',['ModbusException',['../class_kolver_1_1_modbus_exception.html#a8785b0ce9bd7bcd13b6d9d54deb98c68',1,'Kolver.ModbusException.ModbusException()'],['../class_kolver_1_1_modbus_exception.html#a07dc927e4257a4f2ab540af3e31764b2',1,'Kolver.ModbusException.ModbusException(string message)'],['../class_kolver_1_1_modbus_exception.html#a90eac03d95c37a4215e8975983a01f56',1,'Kolver.ModbusException.ModbusException(string message, Exception inner)'],['../class_kolver_1_1_modbus_exception.html#a29a90d8912c6c36d7b07b215af3c5c22',1,'Kolver.ModbusException.ModbusException(string message, int modbusExceptionCode)']]]
];
