var searchData=
[
  ['modbusexception_0',['ModbusException',['../class_kolver_1_1_modbus_exception.html',1,'Kolver']]]
];
