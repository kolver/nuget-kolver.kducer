var searchData=
[
  ['disablescrewdriver_0',['DisableScrewdriver',['../class_kolver_1_1_kducer.html#a84f6fb4839725af410c81357ab62c88a',1,'Kolver::Kducer']]],
  ['dispose_1',['Dispose',['../class_kolver_1_1_kducer.html#afb68cd32800a35cb1f4bfb5799f891da',1,'Kolver::Kducer']]]
];
