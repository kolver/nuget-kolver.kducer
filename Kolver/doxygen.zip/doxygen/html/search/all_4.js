var searchData=
[
  ['hasnewresult_0',['HasNewResult',['../class_kolver_1_1_kducer.html#a44053c8126c12fd3cc466c3a203de745',1,'Kolver::Kducer']]]
];
