var searchData=
[
  ['lockscrewdriverindefinitelyafterresult_0',['LockScrewdriverIndefinitelyAfterResult',['../class_kolver_1_1_kducer.html#a42fece37f2ce06654e998aac471abe8f',1,'Kolver::Kducer']]],
  ['lockscrewdriveruntilgetresult_1',['LockScrewdriverUntilGetResult',['../class_kolver_1_1_kducer.html#a099057510e1610882aeb0c0b41c51549',1,'Kolver::Kducer']]]
];
