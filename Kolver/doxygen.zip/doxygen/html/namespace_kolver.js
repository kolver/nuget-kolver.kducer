var namespace_kolver =
[
    [ "Kducer", "class_kolver_1_1_kducer.html", "class_kolver_1_1_kducer" ],
    [ "KducerControllerGeneralSettings", "class_kolver_1_1_kducer_controller_general_settings.html", "class_kolver_1_1_kducer_controller_general_settings" ],
    [ "KducerSequenceOfTighteningPrograms", "class_kolver_1_1_kducer_sequence_of_tightening_programs.html", "class_kolver_1_1_kducer_sequence_of_tightening_programs" ],
    [ "KducerTighteningProgram", "class_kolver_1_1_kducer_tightening_program.html", "class_kolver_1_1_kducer_tightening_program" ],
    [ "KducerTighteningResult", "class_kolver_1_1_kducer_tightening_result.html", "class_kolver_1_1_kducer_tightening_result" ],
    [ "KducerTorqueAngleTimeGraph", "class_kolver_1_1_kducer_torque_angle_time_graph.html", "class_kolver_1_1_kducer_torque_angle_time_graph" ],
    [ "ModbusException", "class_kolver_1_1_modbus_exception.html", "class_kolver_1_1_modbus_exception" ]
];