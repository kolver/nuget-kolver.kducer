var namespaces_dup =
[
    [ "Kolver", "namespace_kolver.html", "namespace_kolver" ]
];