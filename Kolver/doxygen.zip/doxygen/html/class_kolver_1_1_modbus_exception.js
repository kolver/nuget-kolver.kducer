var class_kolver_1_1_modbus_exception =
[
    [ "ModbusException", "class_kolver_1_1_modbus_exception.html#a8785b0ce9bd7bcd13b6d9d54deb98c68", null ],
    [ "ModbusException", "class_kolver_1_1_modbus_exception.html#a07dc927e4257a4f2ab540af3e31764b2", null ],
    [ "ModbusException", "class_kolver_1_1_modbus_exception.html#a90eac03d95c37a4215e8975983a01f56", null ],
    [ "ModbusException", "class_kolver_1_1_modbus_exception.html#a29a90d8912c6c36d7b07b215af3c5c22", null ],
    [ "GetModbusExceptionCode", "class_kolver_1_1_modbus_exception.html#a6a23c1ec899fbc722a22c59181a13cf2", null ]
];