var hierarchy =
[
    [ "Exception", null, [
      [ "Kolver.ModbusException", "class_kolver_1_1_modbus_exception.html", null ]
    ] ],
    [ "IDisposable", null, [
      [ "Kolver.Kducer", "class_kolver_1_1_kducer.html", null ]
    ] ],
    [ "Kolver.KducerControllerGeneralSettings", "class_kolver_1_1_kducer_controller_general_settings.html", null ],
    [ "Kolver.KducerSequenceOfTighteningPrograms", "class_kolver_1_1_kducer_sequence_of_tightening_programs.html", null ],
    [ "Kolver.KducerTighteningProgram", "class_kolver_1_1_kducer_tightening_program.html", null ],
    [ "Kolver.KducerTighteningResult", "class_kolver_1_1_kducer_tightening_result.html", null ],
    [ "Kolver.KducerTorqueAngleTimeGraph", "class_kolver_1_1_kducer_torque_angle_time_graph.html", null ]
];