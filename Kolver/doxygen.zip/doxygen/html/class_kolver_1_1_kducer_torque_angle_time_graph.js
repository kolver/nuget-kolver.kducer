var class_kolver_1_1_kducer_torque_angle_time_graph =
[
    [ "KducerTorqueAngleTimeGraph", "class_kolver_1_1_kducer_torque_angle_time_graph.html#aec016158a7079bfe9d7147930cc43151", null ],
    [ "KducerTorqueAngleTimeGraph", "class_kolver_1_1_kducer_torque_angle_time_graph.html#a2fa9b75af79d242b43f4ef87a09b88c2", null ],
    [ "getAngleSeries", "class_kolver_1_1_kducer_torque_angle_time_graph.html#a5fdfe3cf23f29f2fe76afb34dcac6c5e", null ],
    [ "getAngleSeriesAsCsv", "class_kolver_1_1_kducer_torque_angle_time_graph.html#a02b1d50aa6c0383f0a19ad55868beb7e", null ],
    [ "getAngleSeriesAsCsvWith70columns", "class_kolver_1_1_kducer_torque_angle_time_graph.html#a17915441f5b4b7817c176b83ce7b199e", null ],
    [ "getTimeIntervalBetweenConsecutivePoints", "class_kolver_1_1_kducer_torque_angle_time_graph.html#ae24aa2475da089ffed8e85b90f9fe700", null ],
    [ "getTorqueSeries", "class_kolver_1_1_kducer_torque_angle_time_graph.html#a31d599edf2da64cede75925e62ea9e68", null ],
    [ "getTorqueSeriesAsCsv", "class_kolver_1_1_kducer_torque_angle_time_graph.html#a4ff1ef40109daa5711954c2911831061", null ],
    [ "getTorqueSeriesAsCsvWith70columns", "class_kolver_1_1_kducer_torque_angle_time_graph.html#ae69d2435e5c2e92ef491fa17f286aa8e", null ]
];